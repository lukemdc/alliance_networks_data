from read_txt import read
from switch_country_names import convert
def append_freedom(filenam,freedom_data):
    print "adding political freedom data"
    old_file=open(filenam,"r")
    lines=read(old_file)
    convert(freedom_data)
    freedom_file=open(freedom_data[:-4]+"_fixednames.txt","r")
    freedom_data=read(freedom_file)
    for line in lines:
        new_data=["."]*6
        for freedom_entry in freedom_data:
            if line[0]==freedom_entry[0]:
                if line[1]==freedom_entry[1]:
                    new_data[:3]=freedom_entry[2:5]
                if line[2]==freedom_entry[1]:
                    new_data[3:6]=freedom_entry[2:5]
        new_data.append("\n")
        line.extend(new_data)
    outs=set()
    for line in lines:
        outs.add("\t".join(line))
    outs=list(outs)
    outs.sort(cmp=None, key=None, reverse=False)
    outfile=open(filenam[:-4]+"_freedom.txt","w")
    outfile.write("year"+"\t"+"country1"+"\t"+"country2"+"\t"
         +"jaccard_index"+"\t"+"hamming_distance"+"\t"+"intersection_count"+"\t"+"union_count"+"\t"
         +"alliance_defense"+"\t"+'neutrality'+"\t"+'nonaggression'+"\t"+'entente'+"\t"
         +"interstate_conflict"+"\t"+"country1_intrastate"+"\t"+"country2_intrastate"+"\t"+"conflict_intensity"+"\t"+"coalition"+"\t"
         +"PR_c1"+"\t"+"CL_c1"+"\t"+"freedom_c1"+"\t"+"PR_c2"+"\t"+"CL_c2"+"\t"+"freedom_c2"+"\n")
    outfile.writelines(outs)
    "    done adding political freedom data"
    return lines
#append_freedom("test_compile_24Oct2015c_jaccard.txt", "freedomhouse_sourcedata.txt")