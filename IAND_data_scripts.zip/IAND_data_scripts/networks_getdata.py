from read_txt import read
from switch_country_names import convert
def get_data(filenam_,new_data_file,yr_inex):
    old_file_=open(filenam_,"r")
    lines_=read(old_file_)
    lines_.sort(cmp=None, key=None, reverse=False)
    #open sourcedata for new variables
    convert(new_data_file)
    new_data_file=open(new_data_file[:-4]+"_fixednames.txt","r")
    new_data_=read(new_data_file)
    new_data_=[e for e in new_data_ if e[yr_inex]>"1959" and e[yr_inex]<"2006"]
    #generate range of years to keep
    years_=set(range(1960,2015))
    years_=set([str(y) for y in years_])
    #news_yr_ is a dict where new data is mapped to years
    news_yr_={y: [] for y in years_}
    #lines_yr is dict where old data mapped to years
    lines_yr_={y: [] for y in years_}
    #these loops populate the dicts
    for i in new_data_:
        if i[yr_inex]>"1959":
            news_yr_[i[yr_inex]].append(i)
    for l in lines_:
        if l[0]>"1959":
            lines_yr_[l[0]].append(l)
    old_file_.close()
    new_data_file.close()
    yield years_
    yield lines_yr_
    yield news_yr_
def get_dyads(lines__,yr_inex__,c1_inex__,c2_inex__):    
    lines__=[e for e in lines__ if e[yr_inex__]>"1959" and e[yr_inex__]<"2006"]
    #dyads is set of unique dyads in form YYYY_c1_c2
    dyads__=set()
    #d_dict maps dyads to data
    d_dict__={}
    for line__ in lines__:
        #dyad is a unique dyad with YYYY_country1_country2
        dyad__="_".join([line__[yr_inex__]]+sorted([line__[c1_inex__],line__[c2_inex__]]))
        d_dict__[dyad__]=line__
        dyads__.add(dyad__)
    yield dyads__
    yield d_dict__