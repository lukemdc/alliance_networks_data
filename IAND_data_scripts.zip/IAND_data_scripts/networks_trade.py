from networks_getdata import get_data
def append_trade(filenam,trade_data):
    print "adding bilateral trade data"
    years,lines,trades=get_data(filenam, trade_data, 0)
    outs=set()
    years=list(years)
    years.sort(cmp=None, key=None, reverse=False)
    for y in years:
        print "    pairing trade data for ", y
        for line in lines[y]:
            missing=1
            for trade in trades[y]:
                if sorted([trade[1],trade[2]])==sorted([line[1],line[2]]):
                    outs.add("\t".join(line)+"\t"+trade[3]+"\n") #this appends the new data
                    missing=0
            if missing==1:  #if no data was added after looping over the new_data, a "." is appended
                outs.add("\t".join(line)+"\t"+"."+"\n")
    outs=list(outs)
    outs.sort(cmp=None, key=None, reverse=False)
    outfile=open(filenam[:-4]+"_trade.txt","w")
    outfile.write("year"+"\t"+"country1"+"\t"+"country2"+"\t"
         +"jaccard_index"+"\t"+"hamming_distance"+"\t"+"intersection_count"+"\t"+"union_count"+"\t"
         +"alliance_defense"+"\t"+'neutrality'+"\t"+'nonaggression'+"\t"+'entente'+"\t"
         +"interstate_conflict"+"\t"+"country1_intrastate"+"\t"+"country2_intrastate"+"\t"+"conflict_intensity"+"\t"+"coalition"+"\t"
         +"PR_c1"+"\t"+"CL_c1"+"\t"+"freedom_c1"+"\t"+"PR_c2"+"\t"+"CL_c2"+"\t"+"freedom_c2"+"\t"+"."+"\t"
         +'east_africa'+"\t"+'middle_africa'+"\t"+'northern_africa'+"\t"+'southern_africa'+"\t"+'western_africa'+"\t"+'caribbean'+"\t"+'central_america'+"\t"
         +'south_america'+"\t"+'north_america'+"\t"+'central_asia'+"\t"+'eastern_asia'+"\t"+'southern_asia'+"\t"+'southeastern_asia'+"\t"+'western_asia'+"\t"
         +'eastern_europe'+"\t"+'northern_europe'+"\t"+'southern_europe'+"\t"+'western_europe'+"\t"+'australia_newzeland'+"\t"
         +"trade"+"\n")
    outfile.writelines(outs)
    print "    done adding bilateral trade data"
    return 0