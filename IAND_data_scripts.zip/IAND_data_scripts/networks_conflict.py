from networks_getdata import get_data
def append_conflicts(filenam,conflict_data):
    print "adding conflict data"
    years,lines,conflicts=get_data(filenam,conflict_data,9)
    outs=set()
    for y in years:
        for line in lines[y]:
            interstate="0"
            intra_c1="0"
            intra_c2="0"
            intensity="0"
            coalition="0"
            for conflict in conflicts[y]:
                countries_sideA=set(conflict[2].split(', '))
                countries_sideB=set(conflict[4].split(', '))
                coalitionA=countries_sideA.union(set(conflict[3].split(', ')))
                coalitionB=countries_sideB.union(set(conflict[6].split(', ')))
                #coalition
                #this checks if the dyad is fighting on the same side
                if (line[1] in coalitionA) and (line[2] in coalitionA):
                    coalition="1"
                if (line[1] in coalitionB) and (line[2] in coalitionB):
                    coalition="1"
                #these if and elif statements create the dummie variables based on the prio data and the jaccard data
                #interstate
                missing=1
                if (line[1] in countries_sideA) and (line[2] in countries_sideB):
                    interstate='1'
                    missing=0
                elif (line[2] in countries_sideA) and (line[1] in countries_sideB):
                    interstate='1'
                    missing=0
                #country1 experiences intrastate
                elif (line[1] in countries_sideA) and (line[2] not in countries_sideB) and conflict[12]!=1:
                    intra_c1='1'
                    missing=0
                #country2 experiences intrastate
                elif (line[2] in countries_sideA) and (line[1] not in countries_sideB) and conflict[12]!=1:
                    intra_c2='1'
                    missing=0
                #conflict intensity
                if missing==0:
                    intensity=conflict[10]
            outs.add("\t".join(line)+"\t"+interstate+"\t"+intra_c1+"\t"+intra_c2+"\t"+intensity+"\t"+coalition+"\n")
    outs=list(outs)
    outs.sort(cmp=None, key=None, reverse=False)
    outfile=open(filenam[:-4]+"_conflicts.txt","w")
    outfile.write("year"+"\t"+"country1"+"\t"+"country2"+"\t"
         +"jaccard_index"+"\t"+"hamming_distance"+"\t"+"intersection_count"+"\t"+"union_count"+"\t"
         +"alliance_defense"+"\t"+'neutrality'+"\t"+'nonaggression'+"\t"+'entente'+"\t"
         +"interstate_conflict"+"\t"+"country1_intrastate"+"\t"+"country2_intrastate"+"\t"+"conflict_intensity"+"\t"+"coalition"+"\n")
    #this was changed from for x in outs: outfile.writelines.x
    outfile.writelines(outs)
    outfile.close()
    print "    done adding conflict data"
    return outs