def read(filename_):
    lines=set()
    aline=filename_.readline()
    aline=filename_.readline()
    while aline:
        aline=aline[:-1]
        lines.add(aline)
        aline=filename_.readline()
    returned_lines=[]
    for line in lines:
        returned_lines.append(line.split("\t"))
    returned_lines.sort(cmp=None, key=None, reverse=False)
    return returned_lines