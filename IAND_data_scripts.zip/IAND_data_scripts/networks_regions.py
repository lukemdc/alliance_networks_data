from read_txt import read
def append_regions(filenam):
    print "adding dummies for geographic regions"
    old_file=open(filenam,'r')
    lines=read(old_file)    
    outfile=open(filenam[:-4]+"_regions.txt",'w')   
    outfile.write("year"+"\t"+"country1"+"\t"+"country2"+"\t"
         +"jaccard_index"+"\t"+"hamming_distance"+"\t"+"intersection_count"+"\t"+"union_count"+"\t"
         +"alliance_defense"+"\t"+'neutrality'+"\t"+'nonaggression'+"\t"+'entente'+"\t"
         +"interstate_conflict"+"\t"+"country1_intrastate"+"\t"+"country2_intrastate"+"\t"+"conflict_intensity"+"\t"+"coalition"+"\t"
         +"PR_c1"+"\t"+"CL_c1"+"\t"+"freedom_c1"+"\t"+"PR_c2"+"\t"+"CL_c2"+"\t"+"freedom_c2"+"\t"+"."+"\t"
         +'east_africa'+"\t"+'middle_africa'+"\t"+'northern_africa'+"\t"+'southern_africa'+"\t"+'western_africa'+"\t"+'caribbean'+"\t"+'central_america'+"\t"
         +'south_america'+"\t"+'north_america'+"\t"+'central_asia'+"\t"+'eastern_asia'+"\t"+'southern_asia'+"\t"+'southeastern_asia'+"\t"+'western_asia'+"\t"
         +'eastern_europe'+"\t"+'northern_europe'+"\t"+'southern_europe'+"\t"+'western_europe'+"\t"+'australia_newzeland'+"\n")
    outs=get_regions(lines)
    outfile.writelines(lines)
    old_file.close()
    outfile.close()
    print "    done adding dummies for geographic regions data"
    return outs
def get_regions(lines_):
    #the regional data from the UN geoscheme
    east_africa=['Tanzania/Tanganyka', 'Rwanda', 'Comoros', 'Djibouti', 'Mauritius', 'Ethiopia', 'Sudan', 'Somalia', 'Zimbabwe/Rhodesia', 'Eritrea', 'Zambia', 'Burundi', 'Malawi', 'Uganda', 'Seychelles', 'Mozambique', 'Kenya', 'Madagascar','Madagascar/Malagasy']
    middle_africa=['Angola', 'Cameroon', 'Central African Rep', 'Chad', 'Congo/Brazzaville', 'Congo DR/Zaire', 'Equatorial Guinea', 'Gabon']
    northern_africa=['Algeria', 'Egypt', 'Egypt/UAR','Libya', 'Morocco', 'Sudan', 'Tunisia', 'Western Sahara']
    southern_africa=["Botswana",'Lesotho','Namibia','South Africa','Swaziland']
    western_africa=['Benin','Benin/Dahomey','Burkina Faso','Burkina Faso/UV', "Cote d'Ivoire", 'Gambia', 'Ghana', 'Guinea', 'Guinea-Bissau', 'Liberia', 'Mali', 'Mauritania', 'Niger', 'Nigeria', 'Saint Helena', 'Senegal', 'Sierra Leone', 'Togo']
    caribbean=['Anguilla', 'Bahamas', 'Barbados', 'Cuba', 'Dominica', 'Dominican Republic', 'Grenada', 'Guadeloupe', 'Haiti', 'Jamaica', 'Martinique', 'Montserrat', 'Puerto Rico']
    central_america=['Belize', 'Costa Rica', 'El Salvador', 'Guatemala', 'Honduras', 'Mexico', 'Nicaragua', 'Panama']
    south_america=['Argentina', 'Bolivia', 'Brazil', 'Chile', 'Colombia', 'Ecuador', 'French Guiana', 'Guyana', 'Paraguay', 'Peru', 'Suriname', 'Uruguay', 'Venezuela']
    north_america=['Bermuda','Canada','Greenland','USA']
    central_asia=['Kazakhstan', 'Kyrgyzstan', 'Tajikistan', 'Turkmenistan', 'Uzbekistan']
    eastern_asia=['Korea South','Taiwan/Formossa','Korea North','China','Japan','Mongolia']
    southern_asia=['Afghanistan', 'Bangladesh', 'Bhutan', 'India', 'Iran', 'Maldives', 'Nepal', 'Pakistan', 'Sri Lanka/Ceylon']
    southeastern_asia=['Brunei Darussalam', 'Cambodia', 'Cambodia/Kampuchea', 'Indonesia', 'Laos', 'Malaysia', 'Myanmar/Burma', 'Papua New Guinea','Philippines', 'Singapore', 'Thailand', 'East Timor', 'Vietnam North', 'Vietnam South', 'Vietnam Sorth']
    western_asia=['Armenia', 'Azerbaijan', 'Bahrain', 'Cyprus', 'Georgia', 'Iraq', 'Israel', 'Jordan', 'Kuwait', 'Lebanon', 'Oman', 'Qatar', 'Saudi Arabia', 'Syria', 'Turkey', 'United Arab Emirates', 'Yemen', 'South Yemen', 'North Yemen']
    eastern_europe=['Belarus', 'Bulgaria', 'Czech Rep', 'Hungary', 'Poland', 'Moldova', 'Romania', 'Russia', 'USSR','Slovakia', 'Ukraine']
    northern_europe=['Denmark', 'Estonia', 'Finland', 'Guernsey', 'Iceland', 'Ireland', 'Latvia', 'Lithuania', 'Norway', 'Sweden', 'UK']
    southern_europe=['Albania', 'Andorra', 'Bosnia-Herzegovina', 'Croatia', 'Gibraltar',  'Greece', 'Montenegro', 'San Marino', 'Serbia', 'Slovenia', 'Yugoslavia/Serbia and Montenegro']
    #note: spain, portugal, gibralter, italy, malta,  were moved to western_europe 
    western_europe=['Austria', 'Belgium', 'France', 'Germany', 'Germany East','Germany West', 'Italy', 'Liechtenstein', 'Luxembourg', 'Malta', 'Monaco', 'Netherlands', 'Portugal', 'Spain', 'Switzerland']
    australia_newzeland=['Australia','New Zeland', 'New Zealand']
    regions=[east_africa,
    middle_africa,
    northern_africa,
    southern_africa,
    western_africa,
    caribbean,
    central_america,
    south_america,
    north_america,
    central_asia,
    eastern_asia,
    southern_asia,
    southeastern_asia,
    western_asia,
    eastern_europe,
    northern_europe,
    southern_europe,
    western_europe,
    australia_newzeland]
    for i in range(len(lines_)):
        dummy=["0"]*19
        for ii in range(len(regions)):
            if any(state in lines_[i] for state in regions[ii]):
                dummy[ii]="1"
        lines_[i]="\t".join(lines_[i])+"\t"+"\t".join(dummy)+"\n"
    return lines_