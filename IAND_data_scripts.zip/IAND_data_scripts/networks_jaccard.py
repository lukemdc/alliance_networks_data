def append_jaccard(filename,igo_data):
    print "configuring dyads and adding jaccard index and hamming distance data"
    source=open(igo_data,"r")
    output=open(filename[:-4]+"_jaccard.txt","w") 
    #state_list is a list of the states included in the analysis.  
    #it excludes small island states and city-states.
    state_list_data=open('master_state_list.txt','r')
    state_list=[each[:-1] for each in state_list_data.readlines()]
    countries=set()
    years=set()
    lines=set()
    aline=source.readline()
    #igos is list of all igos
    igos=aline.split('\t')[4:]
    while aline:
        line=aline.split('\t')
        if line[1] in state_list:
            countries.add(line[1])
            years.add(line[3])
            lines.add("\t".join(line))
        aline=source.readline()
    #data is dict of country_year entries mapped to their IGOS for each year 
    data={}
    for line in lines:
        line=line.split('\t')
        #entry is unique entry coded country_year
        entry=str(line[1]+'\t'+line[3])
        to_add=set()
        for i in range(len(line)-4):
            if line[i]=='1':
                to_add.add(igos[i])
        data[entry]=to_add
    lines=jaccard(data,countries,years)
    #this writes the data headers
    output.write("year"+"\t"+"country1"+"\t"+"country2"+"\t"+"jaccard_index"+"\t"+"hamming_distance"+"\t"+"intersection_count"+"\t"+"union_count"+"\n")
    for line in lines:
        output.write(line+"\n")   
    source.close()
    output.close()
    state_list_data.close()
    print "    done adding jaccard index and hamming distance data"
    return lines
def jaccard(data_,countries_,years_):
    lines_=set()
    entries=set(data_.keys())
    for entry in entries:
        year=entry.split('\t')[1]
        country1=entry.split('\t')[0]
        temp=countries_.copy()
        temp.remove(country1)
        #c1 and c2 are the data for the entry and its pair, c2
        c1=data_[entry]
        for country2 in temp:
            if country2+"\t"+year in entries:
                c2=data_[country2+"\t"+year]
                union_=c1.union(c2)
                intersection=c1.intersection(c2)
                jaccard_stat=len(intersection)/float(len(union_)+.0001)
                hamming=len(union_-c1)+len(union_-c2)
                if country1>country2:
                    line=[year,country2,country1,str(jaccard_stat),str(hamming),str(len(intersection)),str(len(union_))]
                else:
                    line=[year,country1,country2,str(jaccard_stat),str(hamming),str(len(intersection)),str(len(union_))]
                lines_.add('\t'.join(line))
    print "n=",len(lines_)
    lines_=list(lines_)
    lines_.sort(cmp=None, key=None, reverse=False)
    return lines_
def decode(s): #this tiny function solves unicode errors.  
    try:
        return "".join(filter(lambda x: ord(x)<128, s))
    except IndexError or UnicodeEncodeError or TypeError:
        return ""