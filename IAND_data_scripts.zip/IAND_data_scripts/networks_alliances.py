###data from dyad_yearly version
from networks_getdata import get_data
def append_alliances(filenam,alliance_data):
    print "adding alliance data"
    years,lines,alliances=get_data(filenam, alliance_data, 17)
    outs=set()
    for y in years:
        for line in lines[y]:
            missing=1
            for alliance in alliances[y]:
                if sorted([alliance[2],alliance[4]])==sorted([line[1],line[2]]):
                    outs.add("\t".join(line)+"\t"+alliance[13]+"\t"+alliance[14]+"\t"+alliance[15]+"\t"+alliance[16]+"\n")
                    missing=0
            if missing==1:
                outs.add("\t".join(line)+"\t"+"0"+"\t"+"0"+"\t"+"0"+"\t"+"0"+"\n")
    outs=list(outs)
    outs.sort(cmp=None, key=None, reverse=False)
    outfile=open(filenam[:-4]+"_alliances.txt","w")
    outfile.write("year"+"\t"+"country1"+"\t"+"country2"+"\t"
         +"jaccard_index"+"\t"+"hamming_distance"+"\t"+"intersection_count"+"\t"+"union_count"+"\t"
         +"alliance_defense"+"\t"+'neutrality'+"\t"+'nonaggression'+"\t"+'entente'+"\n")
    outfile.writelines(outs)
    print "    done adding alliance data"
    return outs