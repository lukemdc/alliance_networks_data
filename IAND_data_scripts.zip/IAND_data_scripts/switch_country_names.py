import difflib
def convert(filenam):
    masterfile=open('master_state_list.txt','r')
    masterlist=masterfile.readlines()
    masterfile.close()
    targetfile=open(filenam,'r')
    target=targetfile.readlines()
    targetfile.close()
    outfile=open(filenam[:-4]+"_fixednames.txt",'w')
    target_set=set()
    if "trade" in filenam:
        for line in target:
            line=line.split("\t")
            target_set.add(line[1])
            target_set.add(line[2])
    if "prio" in filenam:    
        for line in target:
            line=line.split("\t")
            target_set.add(line[1])
            target_set.add(line[2])
            target_set.add(line[3])
            target_set.add(line[4])   
            target_set.add(line[6])
    if "alliance" in filenam:    
        for line in target:
            line=line.split("\t")
            target_set.add(line[2])
            target_set.add(line[4]) 
    map={}
    for country in target_set:
        try:
            country=decode(country)
            #this gets the closest matches for the names in the sourcedata and the 
            #standardized list from the COW IGO data
            if country not in masterlist:
                match=str(difflib.get_close_matches(country, [decode(x) for x in masterlist], 1,.6)[0])[:-1]
                map[match]=country
        except IndexError:
            continue
    #for trade dataset
    if "trade" in filenam:
        map.pop("Dominican Republic", None)
        map.pop("Togo", None)
        map["Cote d'Ivoire"]="C\xaate d'Ivoire"
    #for prio conflict
    if "prio" in filenam:
        map.pop("South Yemen", None)
        map.pop("Bahamas", None)
        map.pop("Mongolia", None)
        map.pop("Australia", None)
        map['Oman']='State of Oman/Free Oman'
        map['Tanzania/Tanganyka']='Tanzania'
        map['Congo/Brazzaville']='Congo'
        map['Congo DR/Zaire']='DR Congo (Zaire)'  
        map['Myanmar/Burma']='Myanmar (Burma)'
        map['Korea North']='North Korea'
        map['Korea South']='South Korea'
        map['Cambodia']='Cambodia (Kampuchea)'
        map['Russia']='Russia (Soviet Union)'
    if "alliance" in filenam:
        map.pop("Thailand",None)
        map.pop("Panama",None)
        map.pop('Monaco',None)
        map['Germany East']='German Democratic Republic'
        map['Germany West']='German Federal Republic'
        map["Cote d'Ivoire"]='Ivory Coast'
        map['Congo DR/Zaire']='Democratic Republic of the Congo'
        map['Congo/Brazzaville']='Congo'
        map['Vietnam South']='Republic of Vietnam'
        map['Korea North']='North Korea'
        map['Korea South']='South Korea'
        map['Yemen']="Yemen People's Republic"
    '''#this for loop would print the countries whose names were changed
    for x in map.keys():
        if x!=map[x]:
            n=1
            #print x, map[x],"."
    '''
    new="".join(["".join(x) for x in target])
    for x in map.keys():
        new.replace(x,map[x])
    if "prio" in filenam:
        new.replace("Government of ","")
    outfile.write(new)
    outfile.close()
    return 0
def decode(s): #this tiny function solves unicode errors.  
    try:
        return "".join(filter(lambda x: ord(x)<128, s))
    except IndexError or UnicodeEncodeError or TypeError:
        return ""